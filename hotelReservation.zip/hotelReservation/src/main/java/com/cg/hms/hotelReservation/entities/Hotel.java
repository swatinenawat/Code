package com.cg.hms.hotelReservation.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;



import org.springframework.data.annotation.Persistent;

@Entity
@Table(name="Hotel")
public class Hotel 
{
	@Id
	@Persistent
	@Column(name="hotel_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int hotelID;
	@Column(name="city")
	private String  city;
	@Column(name="hotel_name")
	private String  hotelName;
	@Column(name="address")
	private String  address;
	@Column(name="description")
	private String  description;
	@Column(name="avg_rate_pernight")
	private String  cost;
	@Column(name="phone_no1")
	private String  phNo1;
	@Column(name="phone_no2")
	private String  phNo2;
	@Column(name="rating")
	private String  rating;
	@Column(name="email")
	private String  email;
	@Column(name="fax")
	private String fax;
	
	public Hotel()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public Hotel(int hotelID, String city, String hotelName, String address,
			String description, String cost, String phNo1, String phNo2,
			String rating, String email, String fax) {
		super();
		this.hotelID = hotelID;
		this.city = city;
		this.hotelName = hotelName;
		this.address = address;
		this.description = description;
		this.cost = cost;
		this.phNo1 = phNo1;
		this.phNo2 = phNo2;
		this.rating = rating;
		this.email = email;
		this.fax = fax;
	}

	public int getHotelID() {
		return hotelID;
	}

	public void setHotelID(int hotelID) {
		this.hotelID = hotelID;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getHotelName() {
		return hotelName;
	}

	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCost() {
		return cost;
	}

	public void setCost(String cost) {
		this.cost = cost;
	}

	public String getPhNo1() {
		return phNo1;
	}

	public void setPhNo1(String phNo1) {
		this.phNo1 = phNo1;
	}

	public String getPhNo2() {
		return phNo2;
	}

	public void setPhNo2(String phNo2) {
		this.phNo2 = phNo2;
	}

	public String getRating() {
		return rating;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	@Override
	public String toString() {
		return "Hotel [hotelID=" + hotelID + ", city=" + city + ", hotelName="
				+ hotelName + ", address=" + address + ", description="
				+ description + ", cost=" + cost + ", phNo1=" + phNo1
				+ ", phNo2=" + phNo2 + ", rating=" + rating + ", email="
				+ email + ", fax=" + fax + "]";
	}
	
	}
