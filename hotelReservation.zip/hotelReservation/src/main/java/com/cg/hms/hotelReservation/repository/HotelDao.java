package com.cg.hms.hotelReservation.repository;

import org.springframework.data.jpa.repository.JpaRepository;







public interface HotelDao extends JpaRepository<com.cg.hms.hotelReservation.entities.Hotel, Integer> 
{

}
