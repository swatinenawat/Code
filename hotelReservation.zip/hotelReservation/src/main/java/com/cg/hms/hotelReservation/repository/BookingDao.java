package com.cg.hms.hotelReservation.repository;

import org.springframework.data.jpa.repository.JpaRepository;







public interface BookingDao extends JpaRepository<com.cg.hms.hotelReservation.hotels.BookingDetails, Integer> 
{

}
