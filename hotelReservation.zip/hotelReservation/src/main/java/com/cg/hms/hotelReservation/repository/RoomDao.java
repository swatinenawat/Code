package com.cg.hms.hotelReservation.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.hms.hotelReservation.hotels.RoomDetails;







public interface RoomDao extends JpaRepository<com.cg.hms.hotelReservation.hotels.RoomDetails, Integer>
{
	public RoomDetails findByHotelIDAndRoomId(Integer hotelId,Integer roomId);
}
