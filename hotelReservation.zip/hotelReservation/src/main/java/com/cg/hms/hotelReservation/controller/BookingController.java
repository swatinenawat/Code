package com.cg.hms.hotelReservation.controller;
import java.sql.Date;
import java.time.Period;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.hms.hotelReservation.entities.Hotel;
import com.cg.hms.hotelReservation.hotels.BookingDetails;
import com.cg.hms.hotelReservation.hotels.RoomDetails;
import com.cg.hms.hotelReservation.repository.BookingDao;
import com.cg.hms.hotelReservation.repository.HotelDao;
import com.cg.hms.hotelReservation.repository.RoomDao;




@RestController
@RequestMapping("/booking")
public class BookingController
{

	@Autowired
	BookingDao bdao;
	@Autowired
	RoomDao rdao;
	@Autowired
	HotelDao hdao;

	@PostMapping("/bookroom")
	public String insert(@RequestBody BookingDetails booking )
	{
		int hotelId=booking.getHotelID();
		int roomId=booking.getRoomId();
		RoomDetails room=rdao.findByHotelIDAndRoomId(hotelId, roomId);
		int available=Integer.parseInt(room.getAvailability());
		int cust=booking.getNoOfAdults()+booking.getNoOfAdults();
		System.out.println("\n\n\n\nHello\n\n\n\n\n\n\n\n");
		if(cust<=3)
		{
			if(available-cust>=0)
			{
				Date d11=booking.getBookedFrom();
				Date d12=booking.getBookedTo();
				Period p = Period.between(d11.toLocalDate(), d12.toLocalDate());
				int days=p.getDays();
				float price = (float)days*room.getCost();
				String str="Total cost : "+price+"\n";
				available-=1;
				room.setAvailability(Integer.toString(available));
				booking.setAmount(price);
				str=str+"Room Booked Successfully";
				bdao.save(booking);
				return str;
			}
			else
				return "Sorry. No rooms available";
		}
		else
		{
			return "No. of people are greater than 3";
		}
		
		
	}
	
	

	@GetMapping("/status/{bookingId}")
	public BookingDetails bookingStatus(@PathVariable("bookingId") int bookingId )
	{
		BookingDetails booking=bdao.findById(bookingId).get();
		return booking;
	}
	
	@PostMapping("/addroom")
	public String room(@RequestBody RoomDetails room)
	{
		rdao.save(room);
		return "Successful";
	}
	@PostMapping("/addhotel")
	public String hotel(@RequestBody Hotel hotel)
	{
		hdao.save(hotel);
		return "Successful";
	}
	@GetMapping("/hotel")
	public String findHotel(@RequestBody Hotel hotel)
	{
		hdao.save(hotel);
		return "Successful";
	}
	
}
